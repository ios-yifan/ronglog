//
//  RongWrapperLog.h
//  RongWrapperLog
//
//  Created by zhangyifan on 2022/6/14.
//

#import <Foundation/Foundation.h>

//! Project version number for RongWrapperLog.
FOUNDATION_EXPORT double RongWrapperLogVersionNumber;

//! Project version string for RongWrapperLog.
FOUNDATION_EXPORT const unsigned char RongWrapperLogVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <RongWrapperLog/PublicHeader.h>


#import <RongWrapperLog/RCIWLog.h>
